# TravelEase Pro

A stunning full-stack travel planner with PHP backend featuring glassmorphism UI, animated 3D cards, and comprehensive travel planning features.

## Features

- 🎨 Glassmorphism UI with frosted glass cards
- 🔄 Animated 3D destination cards
- 🎥 Full-screen video background
- 🗺️ Interactive SVG world map
- 🔒 Secure JWT authentication
- 📊 MySQL database integration
- 🌤️ Real-time weather data
- 💱 Currency conversion
- 🗺️ Google Maps integration
- 📱 Responsive design

## Prerequisites

- PHP 8.0 or higher
- MySQL 8.0 or higher
- Composer
- Web server (Apache/Nginx)
- Node.js and npm (for frontend assets)

## Installation

1. Clone the repository:

2. Install PHP dependencies:

3. Copy the environment file and configure it:
Edit `.env` file with your database credentials and API keys:
- Database configuration
- JWT secret key
- OpenWeatherMap API key
- Fixer.io API key
- Google Maps API key

4. Initialize the database:

5. Set up your web server:
- Point document root to the `public` directory
- Enable URL rewriting (mod_rewrite for Apache)

## Directory Structure


## Usage

1. Create a new user account via the registration page
2. Log in with your credentials
3. Start planning your trips using the interactive interface
4. Add destinations and create detailed itineraries
5. Generate PDF reports of your travel plans
6. Share your itineraries with travel companions

## API Endpoints

### Authentication
- `POST /api/auth/register` - Register new user
- `POST /api/auth/login` - User login
- `POST /api/auth/refresh` - Refresh JWT token

### Trips
- `GET /api/trips` - Get all user trips
- `POST /api/trips` - Create new trip
- `GET /api/trips/{id}` - Get specific trip
- `PUT /api/trips/{id}` - Update trip
- `DELETE /api/trips/{id}` - Delete trip

### Itineraries
- `GET /api/itineraries/{trip_id}` - Get trip itinerary
- `POST /api/itineraries` - Create itinerary
- `PUT /api/itineraries/{id}` - Update itinerary
- `DELETE /api/itineraries/{id}` - Delete itinerary

## Security

- JWT authentication for API endpoints
- Password hashing using Bcrypt
- Input validation and sanitization
- CSRF protection
- Rate limiting

## Contributing

1. Fork the repository
2. Create your feature branch (`git checkout -b feature/AmazingFeature`)
3. Commit your changes (`git commit -m 'Add some AmazingFeature'`)
4. Push to the branch (`git push origin feature/AmazingFeature`)
5. Open a Pull Request

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Support

For support, please open an issue in the GitHub repository or contact the development team.
