<?php
// src/Database/init.php
namespace App\Database;

class DatabaseInitializer {
    private $conn;

    public function __construct() {
        $this->conn = new \mysqli(
            $_ENV['DB_HOST'],
            $_ENV['DB_USER'],
            $_ENV['DB_PASS']
        );

        if ($this->conn->connect_error) {
            die("Connection failed: " . $this->conn->connect_error);
        }
    }

    public function initialize() {
        // Create database if not exists
        $this->conn->query("CREATE DATABASE IF NOT EXISTS " . $_ENV['DB_NAME']);
        $this->conn->select_db($_ENV['DB_NAME']);

        // Create users table
        $this->createUsersTable();

        // Create trips table
        $this->createTripsTable();

        // Create itineraries table
        $this->createItinerariesTable();

        echo "Database initialized successfully!\n";
    }

    private function createUsersTable() {
        $sql = "CREATE TABLE IF NOT EXISTS users (
            id INT AUTO_INCREMENT PRIMARY KEY,
            name VARCHAR(255) NOT NULL,
            email VARCHAR(255) UNIQUE NOT NULL,
            encrypted_password VARCHAR(255) NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            INDEX idx_email (email)
        )";

        if (!$this->conn->query($sql)) {
            die("Error creating users table: " . $this->conn->error);
        }
    }

    private function createTripsTable() {
        $sql = "CREATE TABLE IF NOT EXISTS trips (
            trip_id INT AUTO_INCREMENT PRIMARY KEY,
            user_id INT NOT NULL,
            title VARCHAR(255) NOT NULL,
            destinations JSON NOT NULL,
            start_date DATE NOT NULL,
            end_date DATE NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
            INDEX idx_user_id (user_id),
            INDEX idx_dates (start_date, end_date)
        )";

        if (!$this->conn->query($sql)) {
            die("Error creating trips table: " . $this->conn->error);
        }
    }

    private function createItinerariesTable() {
        $sql = "CREATE TABLE IF NOT EXISTS itineraries (
            itinerary_id INT AUTO_INCREMENT PRIMARY KEY,
            trip_id INT NOT NULL,
            schedule JSON NOT NULL,
            notes TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            FOREIGN KEY (trip_id) REFERENCES trips(trip_id) ON DELETE CASCADE,
            INDEX idx_trip_id (trip_id)
        )";

        if (!$this->conn->query($sql)) {
            die("Error creating itineraries table: " . $this->conn->error);
        }
    }

    public function __destruct() {
        $this->conn->close();
    }

    public static function run() {
        $initializer = new self();
        $initializer->initialize();
    }
}

// Run the initialization if this script is executed directly
if (php_sapi_name() === 'cli') {
    require_once __DIR__ . '/../../vendor/autoload.php';
    
    // Load environment variables
    $dotenv = \Dotenv\Dotenv::createImmutable(__DIR__ . '/../..');
    $dotenv->load();
    
    DatabaseInitializer::run();
}
