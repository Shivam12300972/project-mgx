<?php
// views/dashboard.php
?>
<style>
.dashboard {
    padding: 2rem;
}

.stats-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
    gap: 1.5rem;
    margin-bottom: 2rem;
}

.stat-card {
    padding: 1.5rem;
    text-align: center;
}

.stat-value {
    font-size: 2rem;
    font-weight: 600;
    margin-bottom: 0.5rem;
}

.stat-label {
    color: var(--accent);
}

.trips-section {
    margin-top: 2rem;
}

.trip-cards {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
    gap: 1.5rem;
}

.trip-card {
    padding: 1.5rem;
    transition: transform 0.3s;
}

.trip-card:hover {
    transform: translateY(-5px);
}
</style>

<div class="dashboard">
    <div class="stats-grid">
        <div class="stat-card glassmorphic">
            <div class="stat-value">12</div>
            <div class="stat-label">Planned Trips</div>
        </div>
        <div class="stat-card glassmorphic">
            <div class="stat-value">5</div>
            <div class="stat-label">Countries Visited</div>
        </div>
        <div class="stat-card glassmorphic">
            <div class="stat-value">28</div>
            <div class="stat-label">Places Explored</div>
        </div>
    </div>

    <div class="trips-section">
        <h2>Your Trips</h2>
        <div class="trip-cards">
            <?php
            // Fetch and display user's trips
            $trips = (new \App\Models\Trip())->getUserTrips(getCurrentUserId());
            foreach ($trips as $trip) {
                $destinations = json_decode($trip['destinations'], true);
                echo "<div class='trip-card glassmorphic'>";
                echo "<h3>{$destinations[0]['name']}</h3>";
                echo "<p>" . count($destinations) . " destinations</p>";
                echo "</div>";
            }
            ?>
        </div>
    </div>
</div>
