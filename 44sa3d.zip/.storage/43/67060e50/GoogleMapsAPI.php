<?php
// src/Utils/GoogleMapsAPI.php
namespace App\Utils;

class GoogleMapsAPI {
    private $apiKey;

    public function __construct() {
        $this->apiKey = $_ENV['GOOGLE_MAPS_API_KEY'];
    }

    public function generateMapEmbed($location) {
        return "https://www.google.com/maps/embed/v1/place?key={$this->apiKey}&q=" . urlencode($location);
    }

    public function generateDirectionsUrl($origin, $destination) {
        return "https://www.google.com/maps/embed/v1/directions?key={$this->apiKey}"
            . "&origin=" . urlencode($origin)
            . "&destination=" . urlencode($destination)
            . "&mode=driving";
    }

    public function getPlaceDetails($placeId) {
        $url = "https://maps.googleapis.com/maps/api/place/details/json"
            . "?place_id=" . urlencode($placeId)
            . "&key=" . $this->apiKey;

        $response = file_get_contents($url);
        return json_decode($response, true);
    }

    public function searchPlaces($query, $location = null) {
        $url = "https://maps.googleapis.com/maps/api/place/textsearch/json"
            . "?query=" . urlencode($query)
            . "&key=" . $this->apiKey;

        if ($location) {
            $url .= "&location=" . urlencode($location['lat'] . ',' . $location['lng']);
        }

        $response = file_get_contents($url);
        return json_decode($response, true);
    }
}
