<?php
// src/Utils/WeatherAPI.php
namespace App\Utils;

use GuzzleHttp\Client;
use Exception;

class WeatherAPI {
    private $client;
    private $apiKey;
    private const BASE_URL = 'https://api.openweathermap.org/data/2.5';

    public function __construct() {
        $this->apiKey = $_ENV['WEATHER_API_KEY'];
        $this->client = new Client([
            'base_uri' => self::BASE_URL,
            'timeout' => 5.0,
        ]);
    }

    public function getCurrentWeather($city) {
        try {
            $response = $this->client->get('/weather', [
                'query' => [
                    'q' => $city,
                    'appid' => $this->apiKey,
                    'units' => 'metric'
                ]
            ]);

            return json_decode($response->getBody()->getContents(), true);
        } catch (Exception $e) {
            return ['error' => 'Weather data unavailable', 'message' => $e->getMessage()];
        }
    }

    public function getForecast($city, $days = 5) {
        try {
            $response = $this->client->get('/forecast', [
                'query' => [
                    'q' => $city,
                    'appid' => $this->apiKey,
                    'units' => 'metric',
                    'cnt' => $days * 8 // 8 forecasts per day
                ]
            ]);

            return json_decode($response->getBody()->getContents(), true);
        } catch (Exception $e) {
            return ['error' => 'Forecast data unavailable', 'message' => $e->getMessage()];
        }
    }
}
