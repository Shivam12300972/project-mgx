<?php
// src/Controllers/ItineraryController.php
namespace App\Controllers;

use App\Models\Itinerary;

class ItineraryController {
    private $itinerary;

    public function __construct() {
        $this->itinerary = new Itinerary();
    }

    public function store() {
        $data = json_decode(file_get_contents('php://input'), true);
        
        if ($this->itinerary->create($data['trip_id'], $data['schedule'])) {
            http_response_code(201);
            echo json_encode(['message' => 'Itinerary created successfully']);
        } else {
            http_response_code(500);
            echo json_encode(['error' => 'Failed to create itinerary']);
        }
    }

    public function show($tripId) {
        $itinerary = $this->itinerary->getByTripId($tripId);
        if ($itinerary) {
            echo json_encode($itinerary);
        } else {
            http_response_code(404);
            echo json_encode(['error' => 'Itinerary not found']);
        }
    }
}
