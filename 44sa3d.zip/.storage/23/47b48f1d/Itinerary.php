<?php
// src/Models/Itinerary.php
namespace App\Models;

class Itinerary {
    private $db;
    
    public function __construct() {
        $this->db = getDbConnection();
    }

    public function create($tripId, $schedule) {
        $stmt = $this->db->prepare("INSERT INTO itineraries (trip_id, schedule) VALUES (?, ?)");
        $scheduleJson = json_encode($schedule);
        $stmt->bind_param("is", $tripId, $scheduleJson);
        return $stmt->execute();
    }

    public function getByTripId($tripId) {
        $stmt = $this->db->prepare("SELECT * FROM itineraries WHERE trip_id = ?");
        $stmt->bind_param("i", $tripId);
        $stmt->execute();
        return $stmt->get_result()->fetch_assoc();
    }

    public function update($itineraryId, $schedule) {
        $stmt = $this->db->prepare("UPDATE itineraries SET schedule = ? WHERE itinerary_id = ?");
        $scheduleJson = json_encode($schedule);
        $stmt->bind_param("si", $scheduleJson, $itineraryId);
        return $stmt->execute();
    }
}
