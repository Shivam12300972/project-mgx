# TravelEase Pro

A stunning full-stack travel planner with PHP backend featuring glassmorphism UI, animated 3D cards, and comprehensive travel planning features.

## Features

- 🎨 Glassmorphism UI with frosted glass cards
- 🔄 Animated 3D destination cards
- 🎥 Full-screen video background
- 🗺️ Interactive SVG world map
- 🔒 Secure JWT authentication
- 📊 MySQL database integration
- 🌤️ Real-time weather data
- 💱 Currency conversion
- 🗺️ Google Maps integration
- 📱 Responsive design

## Prerequisites

- PHP 8.0 or higher
- MySQL 8.0 or higher
- Composer
- Web server (Apache/Nginx)
- Node.js and npm (for frontend assets)

## Installation

1. Clone the repository:


2. Install PHP dependencies:


3. Copy the environment file and configure it:

Edit `.env` file with your database credentials and API keys:
- Database configuration
- JWT secret key
- OpenWeatherMap API key
- Fixer.io API key
- Google Maps API key

4. Initialize the database:


5. Set up your web server:
- Point document root to the `public` directory
- Enable URL rewriting (mod_rewrite for Apache)

## Directory Structure

```
travelease-pro/
├── config/
│   └── config.php
├── public/
│   ├── assets/
│   │   ├── css/
│   │   └── js/
│   └── index.php
├── src/
│   ├── Controllers/
│   │   ├── AuthController.php
│   │   ├── TripController.php
│   │   └── ItineraryController.php
│   ├── Database/
│   │   ├── init.php
│   │   └── Schema.php
│   ├── Models/
│   │   ├── User.php
│   │   ├── Trip.php
│   │   └── Itinerary.php
│   ├── Middleware/
│   │   └── JwtMiddleware.php
│   └── Utils/
│       ├── WeatherAPI.php
│       ├── CurrencyAPI.php
│       ├── GoogleMapsAPI.php
│       ├── PdfGenerator.php
│       └── Helpers.php
├── views/
│   ├── layout.php
│   ├── landing.php
│   ├── dashboard.php
│   ├── trip-builder.php
│   └── packing-checklist.php
├── .env
├── .env.example
├── composer.json
└── README.md
```

## Installation Commands

```bash
# Clone the repository
git clone https://github.com/yourusername/travelease-pro.git
cd travelease-pro

# Install PHP dependencies
composer install

# Copy environment file
cp .env.example .env

# Initialize database
php src/Database/init.php

# Set appropriate permissions
chmod -R 755 public/
chmod -R 755 storage/
```

## Contributing

Please read [CONTRIBUTING.md](CONTRIBUTING.md) for details on our code of conduct, and the process for submitting pull requests.

## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.
