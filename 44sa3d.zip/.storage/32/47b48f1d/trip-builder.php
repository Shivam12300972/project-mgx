<?php
// views/trip-builder.php
?>
<style>
.trip-builder {
    padding: 2rem;
    display: grid;
    grid-template-columns: 2fr 1fr;
    gap: 2rem;
}

.map-section {
    height: 70vh;
}

.timeline-section {
    padding: 1.5rem;
}

.destination-card {
    padding: 1rem;
    margin-bottom: 1rem;
    cursor: move;
}

.timeline {
    position: relative;
    padding: 1rem;
}

.timeline::before {
    content: '';
    position: absolute;
    left: 0;
    top: 0;
    bottom: 0;
    width: 2px;
    background: linear-gradient(to bottom, var(--secondary), var(--accent));
}

.timeline-item {
    margin-left: 1rem;
    padding: 1rem;
    margin-bottom: 1rem;
    position: relative;
}

.timeline-item::before {
    content: '';
    position: absolute;
    left: -1.35rem;
    top: 50%;
    width: 0.7rem;
    height: 0.7rem;
    background: var(--accent);
    border-radius: 50%;
}
</style>

<div class="trip-builder">
    <div class="map-section glassmorphic">
        <!-- Interactive map will be initialized here via JavaScript -->
        <div id="map" style="height: 100%;"></div>
    </div>

    <div class="timeline-section glassmorphic">
        <h2>Your Itinerary</h2>
        <div class="timeline">
            <div class="timeline-item glassmorphic">
                <h3>Paris, France</h3>
                <p>Day 1 - Arrival</p>
            </div>
            <div class="timeline-item glassmorphic">
                <h3>Amsterdam, Netherlands</h3>
                <p>Day 3 - Exploration</p>
            </div>
        </div>
    </div>
</div>

<script src="https://maps.googleapis.com/maps/api/js?key=<?php echo GOOGLE_MAPS_API_KEY; ?>&callback=initMap" async defer></script>
<script>
function initMap() {
    const map = new google.maps.Map(document.getElementById('map'), {
        center: { lat: 48.8566, lng: 2.3522 },
        zoom: 5
    });
}
</script>
