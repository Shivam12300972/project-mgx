<?php
// public/index.php
require __DIR__ . '/../vendor/autoload.php';

session_start();

// Load configuration
require_once __DIR__ . '/../config/config.php';

// Simple router
$request = $_SERVER['REQUEST_URI'];
$method = $_SERVER['REQUEST_METHOD'];

// API Routes
if (strpos($request, '/api/') === 0) {
    header('Content-Type: application/json');
    
    $jwt = getBearerToken();
    if (!validateJwtToken($jwt) && $request !== '/api/auth/login' && $request !== '/api/auth/register') {
        http_response_code(401);
        echo json_encode(['error' => 'Unauthorized']);
        exit;
    }

    switch ($request) {
        case '/api/auth/login':
            (new AuthController())->login();
            break;
        case '/api/auth/register':
            (new AuthController())->register();
            break;
        case '/api/trips':
            $controller = new TripController();
            $method === 'GET' ? $controller->index() : $controller->store();
            break;
        // Add other API routes
        default:
            http_response_code(404);
            echo json_encode(['error' => 'Not found']);
            break;
    }
    exit;
}

// Web Routes
switch ($request) {
    case '/':
        require __DIR__ . '/../views/layout.php';
        require __DIR__ . '/../views/landing.php';
        break;
    case '/dashboard':
        requireAuth();
        require __DIR__ . '/../views/layout.php';
        require __DIR__ . '/../views/dashboard.php';
        break;
    case '/trip-builder':
        requireAuth();
        require __DIR__ . '/../views/layout.php';
        require __DIR__ . '/../views/trip-builder.php';
        break;
    default:
        http_response_code(404);
        require __DIR__ . '/../views/layout.php';
        echo '<h1>404 - Page Not Found</h1>';
        break;
}