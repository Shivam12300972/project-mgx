<?php
// config/config.php
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'travelease');

define('JWT_SECRET', 'your-secret-key-here');
define('JWT_EXPIRY', 3600); // 1 hour

define('WEATHER_API_KEY', 'your-openweathermap-api-key');
define('CURRENCY_API_KEY', 'your-fixer-api-key');
define('GOOGLE_MAPS_API_KEY', 'your-google-maps-api-key');

// Database connection
function getDbConnection() {
    static $conn = null;
    if ($conn === null) {
        $conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
        if ($conn->connect_error) {
            die('Connection failed: ' . $conn->connect_error);
        }
    }
    return $conn;
}