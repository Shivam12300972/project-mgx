<?php
// views/landing.php
?>
<style>
.hero {
    height: 100vh;
    position: relative;
    display: flex;
    align-items: center;
    justify-content: center;
    text-align: center;
    overflow: hidden;
}

.hero-video {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    object-fit: cover;
    z-index: -1;
}

.hero-content {
    padding: 2rem;
    max-width: 800px;
    z-index: 1;
}

.hero-title {
    font-family: 'Poppins', sans-serif;
    font-size: 3rem;
    margin-bottom: 1rem;
}

.hero-description {
    font-size: 1.2rem;
    margin-bottom: 2rem;
}

.cta-button {
    padding: 1rem 2rem;
    font-size: 1.1rem;
    background: var(--secondary);
    color: white;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    transition: transform 0.2s;
}

.cta-button:hover {
    transform: scale(1.05);
}
</style>

<div class="hero">
    <video class="hero-video" autoplay muted loop>
        <source src="/assets/videos/travel-montage.mp4" type="video/mp4">
    </video>
    <div class="hero-content glassmorphic">
        <h1 class="hero-title">Plan Your Dream Journey</h1>
        <p class="hero-description">Create beautiful itineraries, explore destinations, and make your travel dreams come true with TravelEase Pro.</p>
        <button class="cta-button">Start Planning Now</button>
    </div>
</div>