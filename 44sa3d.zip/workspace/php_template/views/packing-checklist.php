<?php
// views/packing-checklist.php
?>
<style>
.packing-checklist {
    max-width: 800px;
    margin: 2rem auto;
    padding: 2rem;
}

.checklist-categories {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
    gap: 1.5rem;
}

.category {
    padding: 1.5rem;
}

.category-title {
    font-family: 'Poppins', sans-serif;
    margin-bottom: 1rem;
    color: var(--accent);
}

.checklist-item {
    display: flex;
    align-items: center;
    margin-bottom: 0.5rem;
}

.checklist-item input[type="checkbox"] {
    margin-right: 0.5rem;
}

.checklist-item.checked {
    text-decoration: line-through;
    opacity: 0.7;
}
</style>

<div class="packing-checklist">
    <h1>Packing Checklist</h1>
    
    <div class="checklist-categories">
        <div class="category glassmorphic">
            <h2 class="category-title">Essentials</h2>
            <div class="checklist-item">
                <input type="checkbox" id="passport">
                <label for="passport">Passport</label>
            </div>
            <div class="checklist-item">
                <input type="checkbox" id="tickets">
                <label for="tickets">Flight Tickets</label>
            </div>
            <div class="checklist-item">
                <input type="checkbox" id="insurance">
                <label for="insurance">Travel Insurance</label>
            </div>
        </div>

        <div class="category glassmorphic">
            <h2 class="category-title">Clothing</h2>
            <div class="checklist-item">
                <input type="checkbox" id="shirts">
                <label for="shirts">T-shirts</label>
            </div>
            <div class="checklist-item">
                <input type="checkbox" id="pants">
                <label for="pants">Pants</label>
            </div>
            <div class="checklist-item">
                <input type="checkbox" id="shoes">
                <label for="shoes">Comfortable Shoes</label>
            </div>
        </div>
    </div>
</div>

<script>
document.querySelectorAll('.checklist-item input[type="checkbox"]').forEach(checkbox => {
    checkbox.addEventListener('change', function() {
        this.parentElement.classList.toggle('checked', this.checked);
    });
});
</script>