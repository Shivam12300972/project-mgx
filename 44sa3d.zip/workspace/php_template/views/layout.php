<?php
// views/layout.php
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TravelEase Pro</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&family=Inter&family=Montserrat:wght@500&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary: #0f4c75;
            --secondary: #3282b8;
            --accent: #bbe1fa;
            --background: rgba(255, 255, 255, 0.1);
        }

        body {
            font-family: 'Inter', sans-serif;
            margin: 0;
            padding: 0;
            background-color: var(--primary);
            color: white;
        }

        .glassmorphic {
            background: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(15px);
            border-radius: 10px;
            border: 1px solid rgba(255, 255, 255, 0.2);
        }

        .nav {
            padding: 1rem 2rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .nav-brand {
            font-family: 'Poppins', sans-serif;
            font-size: 1.5rem;
            font-weight: 600;
        }

        .nav-links {
            display: flex;
            gap: 2rem;
        }

        .nav-links a {
            color: white;
            text-decoration: none;
            font-family: 'Montserrat', sans-serif;
        }
    </style>
</head>
<body>
    <nav class="nav glassmorphic">
        <div class="nav-brand">TravelEase Pro</div>
        <div class="nav-links">
            <a href="/">Home</a>
            <a href="/dashboard">Dashboard</a>
            <a href="/trip-builder">Plan Trip</a>
        </div>
    </nav>
    <main>
        <?php /* Content will be injected here */ ?>
    </main>
</body>
</html>