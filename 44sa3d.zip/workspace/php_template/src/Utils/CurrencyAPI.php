<?php
// src/Utils/CurrencyAPI.php
namespace App\Utils;

use GuzzleHttp\Client;
use Exception;

class CurrencyAPI {
    private $client;
    private $apiKey;
    private const BASE_URL = 'http://data.fixer.io/api';

    public function __construct() {
        $this->apiKey = $_ENV['CURRENCY_API_KEY'];
        $this->client = new Client([
            'base_uri' => self::BASE_URL,
            'timeout' => 5.0,
        ]);
    }

    public function getExchangeRate($from, $to) {
        try {
            $response = $this->client->get('/latest', [
                'query' => [
                    'access_key' => $this->apiKey,
                    'base' => $from,
                    'symbols' => $to
                ]
            ]);

            return json_decode($response->getBody()->getContents(), true);
        } catch (Exception $e) {
            return ['error' => 'Exchange rate unavailable', 'message' => $e->getMessage()];
        }
    }

    public function convertAmount($from, $to, $amount) {
        $rate = $this->getExchangeRate($from, $to);
        
        if (isset($rate['error'])) {
            return $rate;
        }

        return [
            'from' => $from,
            'to' => $to,
            'amount' => $amount,
            'result' => $amount * $rate['rates'][$to]
        ];
    }
}