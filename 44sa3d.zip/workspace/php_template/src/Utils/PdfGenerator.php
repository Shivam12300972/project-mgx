<?php
// src/Utils/PdfGenerator.php
namespace App\Utils;

use TCPDF;

class PdfGenerator {
    private $pdf;

    public function __construct() {
        $this->pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);
        $this->initializeDocument();
    }

    private function initializeDocument() {
        $this->pdf->SetCreator('TravelEase Pro');
        $this->pdf->SetAuthor('TravelEase Pro');
        $this->pdf->SetTitle('Travel Itinerary');
        
        // Set default header data
        $this->pdf->SetHeaderData(PDF_HEADER_LOGO, PDF_HEADER_LOGO_WIDTH, 'TravelEase Pro', 'Travel Itinerary');
        
        // Set margins
        $this->pdf->SetMargins(15, 15, 15);
        $this->pdf->SetHeaderMargin(5);
        $this->pdf->SetFooterMargin(10);
        
        // Set auto page breaks
        $this->pdf->SetAutoPageBreak(TRUE, 25);
    }

    public function generateItinerary($tripData) {
        $this->pdf->AddPage();
        
        // Add trip title
        $this->pdf->SetFont('helvetica', 'B', 20);
        $this->pdf->Cell(0, 10, $tripData['title'], 0, 1, 'C');
        $this->pdf->Ln(10);

        // Add destinations
        $this->pdf->SetFont('helvetica', 'B', 16);
        $this->pdf->Cell(0, 10, 'Destinations', 0, 1, 'L');
        $this->pdf->SetFont('helvetica', '', 12);
        
        foreach ($tripData['destinations'] as $destination) {
            $this->pdf->Cell(0, 8, '• ' . $destination['name'], 0, 1, 'L');
        }
        
        $this->pdf->Ln(10);

        // Add daily schedule
        $this->pdf->SetFont('helvetica', 'B', 16);
        $this->pdf->Cell(0, 10, 'Daily Schedule', 0, 1, 'L');
        
        foreach ($tripData['schedule'] as $day => $activities) {
            $this->pdf->SetFont('helvetica', 'B', 14);
            $this->pdf->Cell(0, 8, 'Day ' . ($day + 1), 0, 1, 'L');
            $this->pdf->SetFont('helvetica', '', 12);
            
            foreach ($activities as $activity) {
                $this->pdf->Cell(0, 8, $activity['time'] . ' - ' . $activity['description'], 0, 1, 'L');
            }
            
            $this->pdf->Ln(5);
        }

        return $this->pdf->Output('itinerary.pdf', 'S');
    }
}