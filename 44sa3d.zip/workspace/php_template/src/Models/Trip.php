<?php
// src/Models/Trip.php
namespace App\Models;

class Trip {
    private $db;
    
    public function __construct() {
        $this->db = getDbConnection();
    }

    public function create($userId, $destinations) {
        $stmt = $this->db->prepare("INSERT INTO trips (user_id, destinations) VALUES (?, ?)");
        $destinationsJson = json_encode($destinations);
        $stmt->bind_param("is", $userId, $destinationsJson);
        return $stmt->execute();
    }

    public function getUserTrips($userId) {
        $stmt = $this->db->prepare("SELECT * FROM trips WHERE user_id = ?");
        $stmt->bind_param("i", $userId);
        $stmt->execute();
        return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    }

    public function update($tripId, $destinations) {
        $stmt = $this->db->prepare("UPDATE trips SET destinations = ? WHERE trip_id = ?");
        $destinationsJson = json_encode($destinations);
        $stmt->bind_param("si", $destinationsJson, $tripId);
        return $stmt->execute();
    }
}