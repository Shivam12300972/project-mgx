<?php
// src/Database/Schema.php
namespace App\Database;

class Schema {
    private $db;

    public function __construct() {
        $this->db = getDbConnection();
    }

    public function createTables() {
        // Users table
        $this->db->query("
            CREATE TABLE IF NOT EXISTS users (
                id INT AUTO_INCREMENT PRIMARY KEY,
                name VARCHAR(255) NOT NULL,
                email VARCHAR(255) UNIQUE NOT NULL,
                encrypted_password VARCHAR(255) NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ");

        // Trips table
        $this->db->query("
            CREATE TABLE IF NOT EXISTS trips (
                trip_id INT AUTO_INCREMENT PRIMARY KEY,
                user_id INT NOT NULL,
                destinations JSON NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users(id)
            )
        ");

        // Itineraries table
        $this->db->query("
            CREATE TABLE IF NOT EXISTS itineraries (
                itinerary_id INT AUTO_INCREMENT PRIMARY KEY,
                trip_id INT NOT NULL,
                schedule JSON NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (trip_id) REFERENCES trips(trip_id)
            )
        ");
    }
}