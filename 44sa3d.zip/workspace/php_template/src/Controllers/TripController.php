<?php
// src/Controllers/TripController.php
namespace App\Controllers;

use App\Models\Trip;

class TripController {
    private $trip;

    public function __construct() {
        $this->trip = new Trip();
    }

    public function index() {
        $userId = getCurrentUserId();
        $trips = $this->trip->getUserTrips($userId);
        echo json_encode($trips);
    }

    public function store() {
        $data = json_decode(file_get_contents('php://input'), true);
        $userId = getCurrentUserId();
        
        if ($this->trip->create($userId, $data['destinations'])) {
            http_response_code(201);
            echo json_encode(['message' => 'Trip created successfully']);
        } else {
            http_response_code(500);
            echo json_encode(['error' => 'Failed to create trip']);
        }
    }

    public function update($tripId) {
        $data = json_decode(file_get_contents('php://input'), true);
        
        if ($this->trip->update($tripId, $data['destinations'])) {
            echo json_encode(['message' => 'Trip updated successfully']);
        } else {
            http_response_code(500);
            echo json_encode(['error' => 'Failed to update trip']);
        }
    }
}